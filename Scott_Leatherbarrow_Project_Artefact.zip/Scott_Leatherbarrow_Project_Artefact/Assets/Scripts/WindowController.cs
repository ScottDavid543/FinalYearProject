﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WindowController : MonoBehaviour {
    public bool broken;
    public bool open;
    public bool locked;
    public GameObject glass;
    public Transform windowPos;
    public Transform openPos;

	// Use this for initialization
	void Start () {
        broken = false;
        open = false;
	}
    private void Update()
    {
        if (broken == true) glass.SetActive(false);
    }

    public void BreakWindow()
    {
        broken = true;
    }
    public void OpenWindow()
    {
        open = true;
        glass.transform.position = openPos.position;
    }
}
