﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CloseDoor<T> : AIState<T>
{
    public CloseDoor(T stateName, StateDrivenBrain controller, float minDuration) : base(stateName, controller, minDuration) { }
    public DoorController door;
    public override void OnEnter()
    {
        base.OnEnter();
        door = brain.colObj.gameObject.GetComponent<DoorController>();
        brain.navAgent.SetDestination(door.closePos.position);
    }

    public override void Act()
    {
        Debug.Log("CloseDoor: Act");
        if (door.open && brain.navAgent.remainingDistance < 0.3)
        {
            door.CloseDoor();
            brain.colObj = null;
        }
    }

    public override void OnLeave()
    {
        base.OnLeave();
    }
}
