﻿using System.Collections;
using UnityEngine;

public class Idle<T> : AIState<T> {

    public Idle(T stateName, StateDrivenBrain controller, float minDuration) : base(stateName, controller, minDuration) { }

    public override void OnEnter()
    {
        base.OnEnter();
        brain.navAgent.ResetPath();
    }

    public override void Act()
    {
        Debug.Log("Idle: Act");
    }

    public override void OnLeave()
    {
        base.OnLeave();
    }
}
