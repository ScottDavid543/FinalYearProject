﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FindKey<T> : AIState<T>
{

    public FindKey(T stateName, StateDrivenBrain controller, float minDuration) : base(stateName, controller, minDuration) { }
    public DoorController door;
    public override void OnEnter()
    {
        base.OnEnter();
        door = brain.colObj.gameObject.GetComponent<DoorController>();
        brain.navAgent.SetDestination(door.key.transform.position);
    }

    public override void Act()
    {
        Debug.Log("FindKey: Act");
        if (brain.navAgent.remainingDistance < 0.5)
        {
            brain.key = door.key;
            door.key.transform.parent = brain.hand;
            door.key.transform.position = brain.hand.transform.position;
        }
    }

    public override void OnLeave()
    {
        base.OnLeave();
        brain.navAgent.isStopped = false;
    }
}
