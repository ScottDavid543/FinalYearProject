﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BreakDoor<T> : AIState<T>
{

    public BreakDoor(T stateName, StateDrivenBrain controller, float minDuration) : base(stateName, controller, minDuration) { }
    public DoorController door;
    public float timer;
    public override void OnEnter()
    {
        base.OnEnter();
        door = brain.colObj.gameObject.GetComponent<DoorController>();
        brain.navAgent.SetDestination(door.openPos.position);
        timer = 1;
    }

    public override void Act()
    {
        Debug.Log("BreakDoor: Act");
        if(door.window == null && door.key == null)
        {
            timer -= Time.deltaTime;
            if (timer <= 0)
            {
                door.Damage();
                timer = 1;
            }
        }
    }

    public override void OnLeave()
    {
        base.OnLeave();
        brain.navAgent.isStopped = false;
    }
}

