﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnlockDoor<T> : AIState<T>
{

    public UnlockDoor(T stateName, StateDrivenBrain controller, float minDuration) : base(stateName, controller, minDuration) { }
    public DoorController door;
    public override void OnEnter()
    {
        base.OnEnter();
        door = brain.colObj.gameObject.GetComponent<DoorController>();
        brain.navAgent.SetDestination(door.openPos.position);
    }

    public override void Act()
    {
        Debug.Log("UnlockDoor: Act");
        if (brain.navAgent.remainingDistance <= 0.3) {
            if (door.locked)
            {
                if (brain.key = door.key)
                {
                    door.UnlockDoor();
                    brain.key.gameObject.SetActive(false);
                    brain.key = null;
                }
            }
        }
    }

    public override void OnLeave()
    {
        base.OnLeave();
        brain.navAgent.isStopped = false;
    }
}

