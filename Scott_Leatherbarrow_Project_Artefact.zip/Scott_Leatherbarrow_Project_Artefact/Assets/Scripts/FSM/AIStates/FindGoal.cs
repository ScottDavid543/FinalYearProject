﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FindGoal<T> : AIState<T>
{

    public FindGoal(T stateName, StateDrivenBrain controller, float minDuration) : base(stateName, controller, minDuration) { }

    public override void OnEnter()
    {
        base.OnEnter();
        brain.navAgent.SetDestination(brain.goal.position);
    }

    public override void Act()
    {
        Debug.Log("FindGoal: Act");
    }

    public override void OnLeave()
    {
        base.OnLeave();
    }
}
