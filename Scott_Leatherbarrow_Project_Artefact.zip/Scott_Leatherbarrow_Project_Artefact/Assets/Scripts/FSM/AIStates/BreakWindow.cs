﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BreakWindow<T> : AIState<T>
{

    public BreakWindow(T stateName, StateDrivenBrain controller, float minDuration) : base(stateName, controller, minDuration) { }
    public WindowController window;
    public override void OnEnter()
    {
        base.OnEnter();
        window = brain.colObj.gameObject.GetComponent<WindowController>();
        brain.navAgent.SetDestination(window.windowPos.position);
    }

    public override void Act()
    {
        Debug.Log("BreakWindow: Act");
        if (window.locked)
        {
            if (brain.navAgent.remainingDistance < 0.2)
            {
                window.BreakWindow();
                brain.colObj = null;
            }
        }
    }

    public override void OnLeave()
    {
        base.OnLeave();
    }
}
