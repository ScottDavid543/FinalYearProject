﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenWindow<T> : AIState<T>
{

    public OpenWindow(T stateName, StateDrivenBrain controller, float minDuration) : base(stateName, controller, minDuration) { }
    public WindowController window;
    public override void OnEnter()
    {
        base.OnEnter();
        window = brain.colObj.gameObject.GetComponent<WindowController>();
        brain.navAgent.SetDestination(window.windowPos.position);
    }

    public override void Act()
    {
        Debug.Log("OpenWindow: Act");
        if (!window.locked)
        {
            if (brain.navAgent.remainingDistance < 0.2)
            {
                window.OpenWindow();
                brain.colObj = null;
            }
        }
    }

    public override void OnLeave()
    {
        base.OnLeave();
        brain.navAgent.isStopped = false;
    }
}
