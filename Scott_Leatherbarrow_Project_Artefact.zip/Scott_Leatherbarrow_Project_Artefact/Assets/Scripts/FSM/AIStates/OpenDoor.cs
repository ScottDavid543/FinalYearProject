﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenDoor<T> : AIState<T>
{

    public OpenDoor(T stateName, StateDrivenBrain controller, float minDuration) : base(stateName, controller, minDuration) { }
    public DoorController door;
    public override void OnEnter()
    {
        base.OnEnter();
        door = brain.colObj.gameObject.GetComponent<DoorController>();
        brain.navAgent.SetDestination(door.openPos.position);
    }

    public override void Act()
    {        
        Debug.Log("OpenDoor: Act");
        if (!door.open && brain.navAgent.remainingDistance < 0.3) 
        {
            if (!door.locked)
            {
                door.OpenDoor();
            }
            else if (door.locked)
            {
                if (door.window != null)
                {
                    brain.navAgent.SetDestination(door.window.GetComponent<WindowController>().windowPos.transform.position);
                }
            }
        }
    }

    public override void OnLeave()
    {
        base.OnLeave();
        brain.navAgent.isStopped = false;
    }
}
