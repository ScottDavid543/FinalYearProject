﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class StateDrivenBrain : AIController {
    public enum AIStates { Idle,FindGoal,OpenDoor,CloseDoor,BreakWindow,FindKey,UnlockDoor,BreakDoor,OpenWindow};
    public FSM<AIStates> stateMachine;
    protected float thinkInterval = 0.4f;
    public NavMeshAgent navAgent;

    public Transform hand;
    public Transform goal;
    public float goalDis;

    public GameObject colObj = null;
    public GameObject key;

    public bool findKey = false;

	// Use this for initialization
	protected void Awake()
    {
        navAgent = this.gameObject.GetComponent<NavMeshAgent>();
        stateMachine = new FSM<AIStates>();
        // Basic Functionality
        stateMachine.AddState(new Idle<AIStates>(AIStates.Idle, this, 0f));
        stateMachine.AddState(new FindGoal<AIStates>(AIStates.FindGoal, this, 0f));
        stateMachine.AddState(new OpenDoor<AIStates>(AIStates.OpenDoor, this, 0f));
        stateMachine.AddState(new CloseDoor<AIStates>(AIStates.CloseDoor, this, 0f));
        stateMachine.AddState(new BreakWindow<AIStates>(AIStates.BreakWindow, this, 0f));

        // Added complex Functionality 
        stateMachine.AddState(new FindKey<AIStates>(AIStates.FindKey, this, 0f));
        stateMachine.AddState(new UnlockDoor<AIStates>(AIStates.UnlockDoor, this, 0f));
        stateMachine.AddState(new BreakDoor<AIStates>(AIStates.BreakDoor, this, 0f));
        stateMachine.AddState(new OpenWindow<AIStates>(AIStates.OpenWindow, this, 0f));

        stateMachine.SetInitialState(AIStates.Idle);

        // Basic Functionality
        stateMachine.AddTransition(AIStates.Idle, AIStates.FindGoal);
        stateMachine.AddTransition(AIStates.FindGoal, AIStates.Idle);
        stateMachine.AddTransition(AIStates.FindGoal, AIStates.OpenDoor);
        stateMachine.AddTransition(AIStates.OpenDoor, AIStates.CloseDoor);
        //stateMachine.AddTransition(AIStates.OpenDoor, AIStates.BreakWindow);
        stateMachine.AddTransition(AIStates.BreakWindow, AIStates.FindGoal);
        stateMachine.AddTransition(AIStates.CloseDoor, AIStates.FindGoal);

        // Added complex Functionality 
        stateMachine.AddTransition(AIStates.OpenDoor, AIStates.FindKey);
        stateMachine.AddTransition(AIStates.OpenDoor, AIStates.BreakDoor);
        stateMachine.AddTransition(AIStates.OpenDoor, AIStates.OpenWindow);
        stateMachine.AddTransition(AIStates.FindKey, AIStates.UnlockDoor);
        stateMachine.AddTransition(AIStates.UnlockDoor, AIStates.OpenDoor);
        stateMachine.AddTransition(AIStates.BreakDoor, AIStates.FindGoal);
        stateMachine.AddTransition(AIStates.OpenWindow, AIStates.BreakWindow);
        stateMachine.AddTransition(AIStates.OpenWindow, AIStates.FindGoal);
    }
    // Basic Functionality
    public bool GuardIdleToFindGoal(State<AIStates> currentState)
    {
        return (goalDis>2);
    }
    public bool GuardFindGoalToIdle(State<AIStates> currentState)
    {
        return (goalDis < 2);
    }
    public bool GuardFindGoalToOpenDoor(State<AIStates> currentState)
    {
        if (colObj != null)
        {
            if (colObj.CompareTag("Door"))
            {
                if (!colObj.GetComponent<DoorController>().broken)
                {
                    return true;
                }
            }
        }
        return false;       
    }
    public bool GuardOpenDoorToCloseDoor(State<AIStates> currentState)
    {
        if (colObj != null)
        {
            if (colObj.CompareTag("Door"))
            {
                if (colObj.GetComponent<DoorController>().open)
                {
                    return true;
                }
            } 
        }
        return false;
    }
    //public bool GuardOpenDoorToBreakWindow(State<AIStates> currentState)
    //{
    //    if (colObj != null)
    //    {
    //        return (colObj.CompareTag("Window"));
    //    }
    //    return false;
    //}
    public bool GuardBreakWindowToFindGoal(State<AIStates> currentState)
    {
        return (colObj == null);
    }
    public bool GuardCloseDoorToFindGoal(State<AIStates> currentState)
    {
        if (navAgent.remainingDistance < 0.3)
        {
            colObj = null;
            return true;
        }
        return false;
    }

    // Added complex Functionality 
    public bool GuardOpenDoorToFindKey(State<AIStates> currentState)
    {
        if (colObj != null)
        {
            if (colObj.CompareTag("Door"))
            {
                if (colObj.GetComponent<DoorController>().locked)
                {
                    if (colObj.GetComponent<DoorController>().key != null)
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    public bool GuardOpenDoorToBreakDoor(State<AIStates> currentState)
    {
        if (colObj != null)
        {
            if (colObj.CompareTag("Door"))
            {
                if (colObj.GetComponent<DoorController>().locked && colObj.GetComponent<DoorController>().key == null && colObj.GetComponent<DoorController>().window == null)
                {
                    return true;
                }
            }
        }
        return false;
    }
    public bool GuardOpenDoorToOpenWindow(State<AIStates> currentState)
    {
        if (colObj != null)
        {
            return (colObj.CompareTag("Window"));
        }
        return false;
    }
    public bool GuardFindKeyToUnlockDoor(State<AIStates> currentState)
    {
        if (colObj != null)
        {
            if (colObj.CompareTag("Door"))
            {
                if(this.key == colObj.GetComponent<DoorController>().key)
                {
                    return true;
                }
            }
        }
        return false;
    }
    public bool GuardUnlockDoorToOpenDoor(State<AIStates> currentState)
    {
        if (colObj != null)
        {
            if (colObj.CompareTag("Door"))
            {
                if (colObj.GetComponent<DoorController>().locked == false)
                {
                    return true;
                }
            }
        }
        return false;
    }
    public bool GuardBreakDoorToFindGoal(State<AIStates> currentState)
    {
        if (colObj != null)
        {
            if (colObj.CompareTag("Door"))
            {
                if (colObj.GetComponent<DoorController>().open)
                {
                    return true;
                }
            }
        }
        return false;
    }
    public bool GuardOpenWindowToBreakWindow(State<AIStates> currentState)
    {
        if (colObj != null)
        {
            if (colObj.CompareTag("Window"))
            {
                if (colObj.GetComponent<WindowController>().locked)
                {
                    return true;
                }
            }
        }
        return false;
    }
    public bool GuardOpenWindowToFindGoal(State<AIStates> currentState)
    {
        return (colObj == null);
    }

    public void Start()
    {
        base.Start();
        StartCoroutine(Think());      
    }

    // Update is called once per frame
    void Update () {
        stateMachine.CurrentState.Act();
        goalDis = Vector3.Distance(goal.position, transform.position);
    }

    protected IEnumerator Think()
    {
        yield return new WaitForSeconds(thinkInterval);
        stateMachine.Check();
        StartCoroutine(Think());
    }

    private void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.CompareTag("Door"))
        {
            colObj = col.gameObject;
        }
        if (col.gameObject.CompareTag("Window"))
        {
            colObj = col.gameObject;
        }
    }
    //private void OnTriggerExit(Collider col)
    //{
    //    colObj = null;
    //}
}
