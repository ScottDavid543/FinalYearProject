﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIController : MonoBehaviour {
    public CharacterController characterController;
    public Rigidbody rb;
    private Vector3 moveDirection;
    public float turnSpeed = 2.0f;
    public float health;

	// Use this for initialization
	public void Start () {
        characterController = this.GetComponent<CharacterController>();
        rb = this.GetComponent<Rigidbody>();
        rb.isKinematic = true;
        rb.useGravity = false;
	}
	
	// Update is called once per frame
	void Update () {
        
    }
}
