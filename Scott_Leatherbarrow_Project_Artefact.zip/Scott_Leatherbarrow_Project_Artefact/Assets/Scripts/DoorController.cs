﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorController : MonoBehaviour {
    public bool open;
    public bool locked;
    public bool broken;

    public float health;

    public GameObject key;
    public GameObject pivot;
    public GameObject window;
    
    public BoxCollider zone;

    public Transform openPos;
    public Transform closePos;

	// Use this for initialization
	void Start () {
        open = false;
        //locked = false;
        health = 100;
	}
    void Update()
    {
        if (!open)
        {
            if (health <= 0)
            {
                locked = false;
                broken = true;
                OpenDoor();
            }
        }
    }

    public void OpenDoor()
    {
        Debug.Log("OPENDOOR");
        if (locked == false)
        {
            open = true;
            pivot.transform.Rotate(0, -90, 0);
            zone.enabled = false;
        }
    }
    public void CloseDoor()
    {
        if(locked == false)
        {
            open = false;
            pivot.transform.Rotate(0, 90, 0);
            zone.enabled = true;
        }        
    }
    public void UnlockDoor()
    {
        locked = false;
    }
    public void Damage()
    {
        Debug.Log("Damage Door!");
        health -= 20;
    }
}
