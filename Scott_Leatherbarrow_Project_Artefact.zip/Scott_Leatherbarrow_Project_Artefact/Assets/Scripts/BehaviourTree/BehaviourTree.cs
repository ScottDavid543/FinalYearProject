﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class BehaviourTree : MonoBehaviour
{
     public ActionNode openWindowAction;
    public ActionNode breakWindowAction;
     public Selector windowSelector;
    public ActionNode goThroughWindowAction;
    public Sequence windowSeqeunce;

    public ActionNode openDoorAction;
     public ActionNode findKeyAction;
     public ActionNode unlockDoorAction;
     public Sequence unlockSequence;
     public ActionNode breakDoorAction;
     public Selector doorSelector;
    public ActionNode closeDoorAction;
    public Sequence doorSequence;

    public ActionNode findGoalAction;
    public Selector rootNode;

    public GameObject colObj = null;

    public Transform goal;
    public float goalDis;

    public NavMeshAgent navAgent;

    public float updateRate;
    public float timer;

    public DoorController door;

    public Transform hand;
    public GameObject key;

    public delegate void TreeExecuted();
    public event TreeExecuted onTreeExecuted;

    public delegate void NodePassed(string trigger);

    void Start()
    {
        navAgent = GetComponent<NavMeshAgent>();
        navAgent.SetDestination(goal.position);

        // Define the action findGoal
        findGoalAction = new ActionNode(findGoal);

        // Define the window actions, selector and sequence they are placed into
        openWindowAction = new ActionNode(openWindow);
        breakWindowAction = new ActionNode(breakWindow);
        windowSelector = new Selector(new List<Node>
        {
            openWindowAction,
            breakWindowAction,
        });
        goThroughWindowAction = new ActionNode(goThroughWindow);
        windowSeqeunce = new Sequence(new List<Node> {
             windowSelector,
             //breakWindowAction,
             goThroughWindowAction,
             findGoalAction,
         });


        // Define the door actions and the sequence they are placed into
        openDoorAction = new ActionNode(openDoor);     
        findKeyAction = new ActionNode(findKey);
        unlockDoorAction = new ActionNode(unlockDoor);
        unlockSequence = new Sequence(new List<Node>
        {
            findKeyAction,
            unlockDoorAction,
            openDoorAction,
        });
        breakDoorAction = new ActionNode(breakDoor);
        doorSelector = new Selector(new List<Node>
        {
            openDoorAction,
            unlockSequence,
            breakDoorAction,
        });
        closeDoorAction = new ActionNode(closeDoor);
        doorSequence = new Sequence(new List<Node> {
            doorSelector,
            closeDoorAction,
            findGoalAction,
        });

        // Defines the root node adding both sequences
        rootNode = new Selector(new List<Node> {
            doorSequence,
            windowSeqeunce,
        });
    }


    public void Evaluate()
    {
         rootNode.Evaluate();
         StartCoroutine(Execute());
    }

    // Tick rate to check through the tree every (n) seconds
    public void Update()
    {
        timer -= Time.deltaTime;
        if (timer < 0)
        {
            Evaluate();
            timer = updateRate;
        }
        goalDis = Vector3.Distance(goal.position, transform.position);

    }

    // AI checking through the tree node states
    private IEnumerator Execute()
    {
        Debug.Log("The AI is thinking...");
        yield return new WaitForSeconds(1.5f);
        //if(doorSelector.nodeState == NodeStates.SUCCESS)
        //{
        //    Debug.Log("Door obstacle opened");
        //}
        //if(doorSequence.nodeState == NodeStates.SUCCESS)
        //{
        //    Debug.Log("Door Opened and Closed");
        //}
        //else if (windowSeqeunce.nodeState == NodeStates.SUCCESS)
        //{
        //    Debug.Log("Window Broken and Climbed Through");
        //}
        //else
        //{
        //    Debug.Log("AI is Working");
        //}

        if (onTreeExecuted != null)
        {
            onTreeExecuted();
        }
    }
    private NodeStates openWindow()
    {
        Debug.Log("Open Window: Start");
        if(colObj != null)
        {
            if (colObj.CompareTag("Window"))
            {
                WindowController window;
                window = colObj.gameObject.GetComponent<WindowController>();
                navAgent.SetDestination(window.windowPos.position);
                if(window.locked == true)
                {
                    Debug.Log("Open Window: Failure");
                    return NodeStates.FAILURE;
                }
                else if(navAgent.remainingDistance < 0.2 && !window.locked)
                {
                    window.OpenWindow();
                    Debug.Log("Open Window: Success");
                    return NodeStates.SUCCESS;
                }               
                return NodeStates.RUNNING;
            }
        }
        Debug.Log("Open Window: Failure");
        return NodeStates.FAILURE;
    }
    private NodeStates breakWindow()
    {
        Debug.Log("Break Window: Start");
        if (colObj != null)
        {
            Debug.Log("WINDOOWW");
            if (colObj.CompareTag("Window"))
            {
               
                WindowController window;
                window = colObj.gameObject.GetComponent<WindowController>();
                navAgent.SetDestination(window.windowPos.position);
                if (navAgent.remainingDistance < 0.5)
                {
                    window.BreakWindow();
                    //colObj = null;
                    Debug.Log("Break Window: Success");
                    return NodeStates.SUCCESS;
                }
                return NodeStates.RUNNING;
            }
        }
        Debug.Log("Break Window: Failure");
        return NodeStates.FAILURE;
    }
    private NodeStates goThroughWindow()
    {
        Debug.Log("Go Through Window: Start");
        if (colObj.CompareTag("Window"))
        {
            if (colObj.GetComponent<WindowController>().broken|| colObj.GetComponent<WindowController>().open)
            {
                navAgent.SetDestination(goal.position);
                Debug.Log("Go Through Window: Success");
                return NodeStates.SUCCESS;
            }
        }
        Debug.Log("Go Through Failure");
        return NodeStates.FAILURE;
    }
    private NodeStates openDoor()
    {
        Debug.Log("Open Door: Start", this.gameObject);
        if (colObj != null)
        {

            if (colObj.CompareTag("Door"))
            {

                door = colObj.gameObject.GetComponent<DoorController>();
               
                if (!door.open /*&& navAgent.remainingDistance < 0.3*/)
                {
                    Debug.Log("doooooor");
                    if (!door.locked)
                    {
                        navAgent.SetDestination(colObj.GetComponent<DoorController>().openPos.position);
                        door.OpenDoor();
                        Debug.Log("Open Door: Success");
                        return NodeStates.SUCCESS;
                    }
                }
                else if (door.open)
                {
                    Debug.Log("Open Door: Success");
                    return NodeStates.SUCCESS;
                }
            }
            else
            {
                Debug.Log("Open Door: Failure");
                return NodeStates.FAILURE;
            }
        }
        Debug.Log("Open Door: Failure");
        return NodeStates.FAILURE;
    }

    private NodeStates findKey()
    {
        Debug.Log("Find Key: Start");
        if(this.key)
        {
            Debug.Log("Find Key: Success");
            return NodeStates.SUCCESS;
        }
        
        if (door != null)
        {
            if (door.key != null && door.locked)
            {             
                navAgent.SetDestination(door.key.transform.position);
                if (navAgent.remainingDistance < 0.5 && colObj == null) 
                {
                    key = door.key;
                    door.key.transform.parent = hand;
                    door.key.transform.position = hand.transform.position;
                    Debug.Log("Find Key: Success");
                    return NodeStates.SUCCESS;
                }
            }
            else if (door.key == null)
            {
                Debug.Log("Find Key: Failure");
                return NodeStates.FAILURE;
            }
        }

        Debug.Log("Find Key: Failure");
        return NodeStates.FAILURE;
    }
    private NodeStates unlockDoor()
    {
        Debug.Log("Unlock Door: Start");
        if(door != null)
        {
            
            if (key != null)
            {
                navAgent.SetDestination(door.openPos.position);
                Debug.Log(navAgent.destination);
                Debug.Log(navAgent.remainingDistance);
                if (key == door.key && navAgent.remainingDistance < 0.5 && colObj != null)
                {
                    door.UnlockDoor();
                    key.gameObject.SetActive(false);
                    key = null;
                    Debug.Log("Unlock Door: Success");
                    return NodeStates.SUCCESS;
                }
            }
        }
        Debug.Log("Unlock Door: Failure");
        return NodeStates.FAILURE;
    }
    private NodeStates breakDoor()
    {
        Debug.Log("Break Door: Start");
        if (colObj != null)
        {
            if (colObj.CompareTag("Door"))
            {
                
                if (door.window == null && door.key == null)
                {
                    navAgent.SetDestination(door.openPos.position);
                    door.Damage();
                    if (door.health <= 0)
                    {
                        Debug.Log("Break Door: Success");
                        return NodeStates.SUCCESS;
                    }
                }
                else if (door.window != null)
                {
                    navAgent.SetDestination(door.window.GetComponent<WindowController>().windowPos.transform.position);
                    Debug.Log("Break Door: Failure");
                    return NodeStates.FAILURE;
                }
            }
        }
        Debug.Log("Break Door: Failure");
        return NodeStates.FAILURE;
    }
    private NodeStates closeDoor()
    {
        Debug.Log("Close Door: Start");
        navAgent.SetDestination(door.closePos.position);
        float dis = Vector3.Distance(navAgent.destination, this.transform.position);
        if (door.open)
        {
            navAgent.SetDestination(door.closePos.position);

                StartCoroutine(cDoor(door));
                colObj = null;
                Debug.Log("Close Door: Success");
                return NodeStates.SUCCESS;
            
        }
        Debug.Log("Close Door: Failure");
        return NodeStates.FAILURE;
    }
    private NodeStates findGoal()
    {
        Debug.Log("Find Goal: Start");
        
        if (goalDis > 2)
        {
            navAgent.SetDestination(goal.position);
            Debug.Log("Find Goal: Running");
            return NodeStates.RUNNING;
        }
        else if (goalDis < 2)
        {
            navAgent.ResetPath();
            Debug.Log("Find Goal: Success");
            return NodeStates.SUCCESS;
        }
        Debug.Log("Find Goal: Failure");
        return NodeStates.FAILURE;
    }
    IEnumerator cDoor(DoorController door)
    {
        yield return new WaitForSeconds(1f);
        door.CloseDoor();
    }

    private void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.CompareTag("Door"))
        {
            colObj = col.gameObject;
            
        }
        if (col.gameObject.CompareTag("Window"))
        {
            colObj = col.gameObject;
        }
    }
    private void OnTriggerExit(Collider col)
    {
        colObj = null;
    }
}
