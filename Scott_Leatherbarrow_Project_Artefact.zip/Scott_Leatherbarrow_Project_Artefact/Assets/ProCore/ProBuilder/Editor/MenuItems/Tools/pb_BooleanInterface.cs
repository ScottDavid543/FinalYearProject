﻿/**
 * Moved to EditorCore. This file remains for backwards compatibility reasons. You may safely delete it.
 */
